<x-layouts.app.admin>
    <flux:main>
        {{ $slot }}
    </flux:main>
</x-layouts.app.admin>