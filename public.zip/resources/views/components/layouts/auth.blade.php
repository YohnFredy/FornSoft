<x-layouts.auth.card>
    {{ $slot }}
</x-layouts.auth.card>
