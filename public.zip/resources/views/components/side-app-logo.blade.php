{{-- <div>
    <img class="my-1" src="{{ asset('storage/images/logo_fornuvi_pequeño.png') }}" alt="">
</div> --}}

<div class="">
    <div class="font-abril text-3xl font-semibold tracking-widest pl-0.5 sm:pl-1 flex justify-center -mb-1">
        <span class=" text-primary">FOR</span>
        <span class=" text-secondary">NU</span>
        <span class=" text-primary">VI</span>
    </div>
   
        <div class=" w-full h-0.5 bg-gradient-to-r from-white via-secondary to-white"></div>

    <div class="font-kite flex justify-center mt-0.5 ">
        <span class=" text-secondary text-[9.5px]">FORTALECIENDO NUESTRA VIDA</span>
    </div>
</div>
