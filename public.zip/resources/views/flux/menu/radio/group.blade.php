
<ui-menu-radio-group {{ $attributes }} data-flux-menu-radio-group>
    {{ $slot }}
</ui-menu-radio-group>
