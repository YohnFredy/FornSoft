
<ui-close data-flux-modal-close>
    {{ $slot }}
</ui-close>
