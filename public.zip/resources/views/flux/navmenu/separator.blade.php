
<div class="-mx-[.3125rem] my-[.3125rem] h-px" {{ $attributes }} data-flux-navmenu-separator>
    <flux:separator class="dark:bg-zinc-600!" />
</div>
