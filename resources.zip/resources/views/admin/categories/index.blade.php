<x-layouts.admin title="categories">
    @livewire('admin.categories.category-index')
</x-layouts.admin>