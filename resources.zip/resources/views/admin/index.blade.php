<x-layouts.admin title="home">
  
    @livewire('admin.orders.orders-management')
</x-layouts.admin>