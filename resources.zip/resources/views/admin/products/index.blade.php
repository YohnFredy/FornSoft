<x-layouts.admin title="categories">
    @livewire('admin.products.product-index')
</x-layouts.admin>