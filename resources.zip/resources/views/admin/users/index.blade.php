<x-layouts.admin title="categories">
    @livewire('admin.users.user-index')
</x-layouts.admin>