
<div {{ $attributes->class('flex') }} data-flux-breadcrumbs>
    {{ $slot }}
</div>
