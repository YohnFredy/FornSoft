<x-layouts.app title="Show">
    <div class="max-w-5xl mx-auto sm:px-6 lg:px-8">
        <div
            class="flex flex-col sm:flex-row items-center bg-white rounded-lg py-4 sm:py-8 px-6 sm:px-12 border border-neutral-200 shadow-md mb-6 space-y-4 sm:space-y-0 sm:space-x-4">
            <!-- Paso 1: Recibido -->
            <div class="flex flex-col items-center relative sm:flex-1">
                <div
                    class="{{ $order->status >= 2 && $order->status < 6 ? 'bg-primary' : 'bg-neutral-300' }} rounded-full h-12 w-12 flex items-center justify-center">
                    <i class="fas fa-check text-white"></i>
                </div>
                <p class="text-sm mt-2">Recibido</p>
            </div>

            <!-- Línea de progreso -->
            <div
                class="w-full sm:w-auto sm:flex-1 h-1 {{ $order->status >= 2 && $order->status < 6 ? 'bg-primary' : 'bg-neutral-300' }}">
            </div>

            <!-- Paso 2: Enviado -->
            <div class="flex flex-col items-center relative sm:flex-1">
                <div
                    class="{{ $order->status >= 4 && $order->status < 6 ? 'bg-primary' : 'bg-neutral-300' }} rounded-full h-12 w-12 flex items-center justify-center">
                    <i class="fas fa-truck text-white"></i>
                </div>
                <p class="text-sm mt-2">Enviado</p>
            </div>

            <!-- Línea de progreso -->
            <div
                class="w-full sm:w-auto sm:flex-1 h-1 {{ $order->status >= 4 && $order->status < 6 ? 'bg-primary' : 'bg-neutral-300' }}">
            </div>

            <!-- Paso 3: Entregado -->
            <div class="flex flex-col items-center relative sm:flex-1">
                <div
                    class="{{ $order->status >= 5 && $order->status < 6 ? 'bg-primary' : 'bg-neutral-300' }} rounded-full h-12 w-12 flex items-center justify-center">
                    <i class="fas fa-check text-white"></i>
                </div>
                <p class="text-sm mt-2">Entregado</p>
            </div>
        </div>


        <!-- Order Reference -->
        <div class="bg-white rounded-lg p-6 border border-neutral-200 shadow-md mb-6 text-center">
            <p class="text-lg font-semibold text-primary uppercase">Referencia:
                <span>{{ $order->public_order_number }}</span>
            </p>
        </div>

        <!-- Shipping and Contact Details -->
        <div class="bg-white rounded-lg p-6 border border-neutral-200 shadow-md mb-6">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <!-- Shipping Details -->
                <div>
                    <p class="text-lg font-semibold  uppercase mb-4">Detalles de Envío</p>
                    @if ($order->envio_type == 1)
                        <p class="">Recogida en tienda:</p>
                        <p class="">Calle 15 #42, Cali, Valle del Cauca</p>
                    @else
                        <p class="font-medium">Dirección:</p>
                        <p class="text-neutral-600">{{ $order->address }} - {{ $order->additional_address }}
                        </p>
                        <p class="text-neutral-600">{{ $order->country->name }} -
                            {{ $order->department->name }} -
                            @if (!$order->city_id == null)
                                {{ $order->city->name }}
                            @else
                                {{ $order->addCity }}
                            @endif
                        </p>
                    @endif
                </div>

                <!-- Contact Details -->
                <div>
                    <p class="text-lg font-semibold text-primary uppercase mb-4">Contacto</p>
                    <p class="">Recibe: {{ $order->contact }}</p>
                    <p class="">Teléfono: {{ $order->phone }}</p>
                </div>
            </div>
        </div>

        <div class="sm:bg-white sm:rounded-lg pt-8  sm:p-6 sm:shadow-md sm:border sm:border-neutral-200 mb-6">
            <h2 class="text-lg font-semibold text-primary uppercase flex items-center gap-2 mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5" viewBox="0 0 24 24" fill="none"
                    stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <rect width="20" height="14" x="2" y="5" rx="2" />
                    <line x1="2" x2="22" y1="10" y2="10" />
                </svg>
                Resumen de Pedido
            </h2>
            <div class="overflow-x-auto  sm:mx-0 rounded-lg border border-neutral-200">
                <table class="w-full  text-sm text-left rtl:text-right text-neutral-600">
                    <thead class="text-xs bg-primary text-white uppercase">

                        <tr>
                            <th scope="col" class="px-4 sm:px-6 py-3">Producto</th>
                            <th scope="col" class="px-2 sm:px-6 py-3 text-center">Cant</th>
                            <th scope="col" class="px-2 sm:px-6 py-3 text-center">Prec. Unit.</th>
                            <th scope="col" class="px-2 sm:px-6 py-3 text-center">Pts. Unit.</th>
                            <th scope="col" class="px-2 sm:px-6 py-3 text-center">Subtotal</th>
                        </tr>
                    </thead>
                    <tbody>


                        @foreach ($order->items as $item)
                            <tr class="border-b border-neutral-200 hover:bg-neutral-50">
                                <th scope="row"
                                    class="flex items-center px-4 sm:px-6 py-3 font-medium text-neutral-900 whitespace-nowrap">
                                    @if ($item->product->latestImage)
                                        <img src="{{ asset('storage/' . $item->product->latestImage->path) }}"
                                            alt="{{ $item->product->name }}" class="w-10 h-10 rounded-md object-cover">
                                    @else
                                        <img src="{{ asset('images/default.png') }}" alt="{{ $item->product->name }}"
                                            class="w-10 h-10 rounded-md object-cover">
                                    @endif
                                    <div class="ps-3 max-w-[180px] sm:max-w-none">
                                        <div class="text-xs sm:text-sm font-semibold truncate">{{ $item->name }}
                                        </div>
                                    </div>
                                </th>
                                <td class="px-2 sm:px-6 py-3 text-center">{{ $item->quantity }}</td>
                                <td class="px-2 sm:px-6 py-3 text-center">${{ number_format($item->final_price, 0) }}
                                </td>
                                <td class="px-2 sm:px-6 py-3 text-center">{{ number_format($item->pts, 2) }}</td>
                                <td class="px-2 sm:px-6 py-3 text-center">
                                    ${{ number_format($item->final_price * $item->quantity, 0) }}
                                </td>

                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Payment Summary -->
        <div class="sm:bg-white rounded-lg sm:p-6 sm:border sm:border-neutral-200 sm:shadow-md text-center">
            <div class="flex flex-col md:flex-row md:justify-between md:items-start">
                {{-- Imagen en la mitad en pantallas grandes --}}
                <div class="w-full md:w-1/2 flex justify-center md:justify-start mb-4 md:mb-0">
                    <img src="https://www.agenciatravelfest.com/wp-content/uploads/2022/10/logos-medios-de-pago.jpg"
                        class="w-full h-24 object-contain rounded-md" alt="Métodos de Pago">
                </div>

                {{-- Detalles de la orden --}}
                <div class="w-full md:w-1/2 md:pl-6">
                    <div class="flex justify-between items-center border-t pt-2">
                        <span class="font-semibold">Subtotal productos:</span>
                        <span>${{ number_format($order->subtotal, 0) }}</span>
                    </div>

                    @if ($order->discount > 0)
                        <div class="flex justify-between items-center border-t pt-2">
                            <span class="font-semibold">Descuento:</span>
                            <span class="text-red-600">- ${{ number_format($order->discount, 0) }}</span>
                        </div>

                        <div class="flex justify-between items-center border-t pt-2">
                            <span class="font-semibold">Subtotal descuento:</span>
                            <span>${{ number_format($order->subtotal - $order->discount, 0) }}</span>
                        </div>
                    @endif

                    <div class="flex justify-between items-center border-t pt-2">
                        <span class="font-semibold">Subtotal (Sin IVA):</span>
                        <span>${{ number_format($order->taxable_amount, 0) }}</span>
                    </div>
                    <div class="flex justify-between items-center border-t pt-2">
                        <span class="font-semibold">IVA:</span>
                        <span>${{ number_format($order->tax_amount, 0) }}</span>
                    </div>

                    @if ($order->shipping_cost > 0)
                        <div class="flex justify-between items-center border-t pt-2">
                            <span class="font-semibold">Envío:</span>
                            <span>${{ number_format($order->shipping_cost, 0) }}</span>
                        </div>
                    @endif

                    <div class="flex justify-between items-center border-t pt-2">
                        <span class="font-semibold">Total a Pagar:</span>
                        <span class="text-black font-bold text-lg">${{ number_format($order->total, 0) }}</span>
                    </div>
                    <div class="flex justify-between items-center text-sm text-primary mt-1 border-t pt-2">
                        <span>Puntos Acumulados:</span>
                        <span>{{ $order->total_pts }} pts</span>
                    </div>
                </div>
            </div>
        </div>

    </div>


    <!-- Incluir el archivo JavaScript separado -->
    <script src="{{ asset('js/boldCheckout.js') }}"></script>

</x-layouts.app>
