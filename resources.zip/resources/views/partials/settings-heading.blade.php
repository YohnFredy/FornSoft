<div class="relative mb-6 w-full">
    <flux:heading size="xl" level="1">Ajustes</flux:heading>
    <flux:subheading size="lg" class="mb-6">Administra tu perfil y la configuración de tu cuenta</flux:subheading>
    <flux:separator variant="subtle" />
</div>
